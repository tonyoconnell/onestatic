
module.exports = function sub(a, b){
    return a - b;
};