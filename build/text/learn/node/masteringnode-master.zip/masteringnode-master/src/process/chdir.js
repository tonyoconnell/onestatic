
console.log('cwd: %s', process.cwd());
process.chdir(__dirname);
console.log('cwd: %s', process.cwd());