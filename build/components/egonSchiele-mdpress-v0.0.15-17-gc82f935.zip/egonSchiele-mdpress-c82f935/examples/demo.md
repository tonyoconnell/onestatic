---
author: Aditya Bhargava
title: All about chicken
---
# Just because
## my middle name

is **Pancake**,

> doesn't mean you can put syrup on me before I'm ready to come out of the oven.

	mdpress++

---
= data-x='1000'
# Let's Make Lists!

1. Chicken
2. *Emphasized Chicken*
3. [Chicken Link](http://github.com/egonschiele/mdpress)

- unordered `chicken = 1`


