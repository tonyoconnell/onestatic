# Here's some code!

    def fib x
      return x if x < 2
      fib(x - 1) + fib(x - 2)
    end
