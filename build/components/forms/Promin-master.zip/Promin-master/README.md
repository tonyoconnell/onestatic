Promin
======

A jQuery plugin to boost your HTML forms to level awesome!

By presenting the form in chunks, it will consume less space, look better and improves a user’s experience.

For more information and documentation, see http://timseverien.nl/projects/promin/
